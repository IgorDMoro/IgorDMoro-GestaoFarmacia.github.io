package com.igordmoro.farmacia.GestaoFarmacia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoFarmaciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
