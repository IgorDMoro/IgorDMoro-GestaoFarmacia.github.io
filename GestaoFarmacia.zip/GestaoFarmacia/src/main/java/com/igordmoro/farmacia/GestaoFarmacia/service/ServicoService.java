package com.igordmoro.farmacia.GestaoFarmacia.service;

import com.igordmoro.farmacia.GestaoFarmacia.entity.*;
import com.igordmoro.farmacia.GestaoFarmacia.repository.ProdutoRepository;
import com.igordmoro.farmacia.GestaoFarmacia.repository.ServicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class ServicoService {

    private final ServicoRepository servicoRepository;
    private final ProdutoRepository produtoRepository;

    @Autowired
    public ServicoService(ServicoRepository servicoRepository, ProdutoRepository produtoRepository) {
        this.servicoRepository = servicoRepository;
        this.produtoRepository = produtoRepository;
    }

    @Transactional
    public Servico salvarServico(Servico servico) {
        // ✔️ Validações básicas
        if (servico.getFuncionario() == null || servico.getFuncionario().getIdFuncionario() == null) {
            throw new IllegalArgumentException("Serviço deve ter um funcionário associado.");
        }
        if (servico.getTransportadora() == null || servico.getTransportadora().getId() == null) {
            throw new IllegalArgumentException("Serviço deve ter uma transportadora associada.");
        }
        if (servico.getData() == null) {
            throw new IllegalArgumentException("Data do serviço não pode ser nula.");
        }
        if (servico.getTipoServico() == null) {
            throw new IllegalArgumentException("Tipo de serviço (COMPRA/VENDA) não pode ser nulo.");
        }
        if (servico.getStatus() == null) {
            servico.setStatus(Status.ABERTO);
        }

        double valorTotal = 0.0;

        // ✔️ Verifica se listas são coerentes
        for (int i = 0; i < servico.getProdutos().size(); i++) {
            final int index = i; // ✅ Variável auxiliar final

            Produto produto = produtoRepository.findById(
                    servico.getProdutos().get(index).getIdProduto()
            ).orElseThrow(() -> new IllegalArgumentException(
                    "Produto não encontrado com ID: " + servico.getProdutos().get(index).getIdProduto()
            ));

            int quantidade = servico.getQuantidades().get(index);

            if (quantidade <= 0) {
                throw new IllegalArgumentException("Quantidade do produto " + produto.getNome() + " deve ser maior que zero.");
            }

            if (servico.getTipoServico() == TipoServico.VENDA) {
                if (produto.getQuantidadeEstoque() < quantidade) {
                    throw new IllegalArgumentException(
                            "Estoque insuficiente para o produto: " + produto.getNome() +
                                    ". Disponível: " + produto.getQuantidadeEstoque() +
                                    ", Solicitado: " + quantidade
                    );
                }
                produto.setQuantidadeEstoque(produto.getQuantidadeEstoque() - quantidade);
            } else if (servico.getTipoServico() == TipoServico.COMPRA) {
                produto.setQuantidadeEstoque(produto.getQuantidadeEstoque() + quantidade);
            }

            produtoRepository.save(produto);

            double precoUnitario = (servico.getTipoServico() == TipoServico.VENDA)
                    ? produto.getPrecoVenda()
                    : produto.getPrecoCusto();

            valorTotal += precoUnitario * quantidade;
        }



        servico.setValor(valorTotal);
        return servicoRepository.save(servico);
    }

    @Transactional
    public List<Servico> listarTodosServicos() {
        return servicoRepository.findAll();
    }

    @Transactional
    public Optional<Servico> buscarServicoPorId(Long id) {
        return servicoRepository.findById(id);
    }

    @Transactional
    public void deletarServico(Long id) {
        if (!servicoRepository.existsById(id)) {
            throw new IllegalArgumentException("Serviço não encontrado com ID: " + id);
        }
        servicoRepository.deleteById(id);
    }

    @Transactional
    public void cancelarServico(Long id) {
        Servico servico = servicoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Serviço não encontrado com ID: " + id));

        if (servico.getStatus() == Status.CONCLUÍDO) {
            throw new IllegalStateException("Não é possível cancelar um serviço já concluído.");
        }

        servico.setStatus(Status.CANCELADO);
        servicoRepository.save(servico);
    }

    @Transactional
    public void concluirServico(Long id) {
        Servico servico = servicoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Serviço não encontrado com ID: " + id));

        if (servico.getStatus() == Status.CANCELADO) {
            throw new IllegalStateException("Não é possível concluir um serviço cancelado.");
        }

        servico.setStatus(Status.CONCLUÍDO);
        servicoRepository.save(servico);
    }

    @Transactional
    public List<Servico> listarServicosEmAberto() {
        return servicoRepository.findByStatus(Status.ABERTO);
    }
}
