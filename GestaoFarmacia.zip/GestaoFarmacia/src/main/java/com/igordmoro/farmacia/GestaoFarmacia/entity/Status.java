package com.igordmoro.farmacia.GestaoFarmacia.entity;

public enum Status {
	ABERTO,
	CONCLUÍDO,
	CANCELADO
}
