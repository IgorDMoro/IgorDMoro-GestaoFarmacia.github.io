package com.igordmoro.farmacia.GestaoFarmacia.controller;

import com.igordmoro.farmacia.GestaoFarmacia.entity.Cargo;
import com.igordmoro.farmacia.GestaoFarmacia.repository.CargoRepository;
import com.igordmoro.farmacia.GestaoFarmacia.service.FuncionarioService; // Importar FuncionarioService
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/cargos")
public class CargoWebController {

    @Autowired
    private CargoRepository cargoRepository;

    @Autowired // Injetar FuncionarioService
    private FuncionarioService funcionarioService;

    @GetMapping
    public String listarCargos(Model model) {
        List<Cargo> cargos = cargoRepository.findAll();
        // Obter a contagem de funcionários por cargo
        Map<Long, Long> contagemFuncionariosPorCargo = funcionarioService.contarFuncionariosPorCargo(); //

        // Criar uma lista de DTOs ou um Map para passar para a view
        // Cada item terá o Cargo e a quantidade de funcionários associados a ele
        List<Map<String, Object>> cargosComContagem = cargos.stream().map(cargo -> {
            Map<String, Object> cargoInfo = new java.util.HashMap<>();
            cargoInfo.put("cargo", cargo);
            cargoInfo.put("quantidadeFuncionarios", contagemFuncionariosPorCargo.getOrDefault(cargo.getId(), 0L));
            return cargoInfo;
        }).collect(Collectors.toList());

        model.addAttribute("cargosComContagem", cargosComContagem); // Mudar o nome do atributo para a view
        return "cargos";
    }

    @GetMapping("/form")
    public String showAddForm(Model model) {
        model.addAttribute("cargo", new Cargo());
        return "cargo-form";
    }

    @PostMapping
    public String saveCargo(@ModelAttribute Cargo cargo, RedirectAttributes redirectAttributes) {
        cargoRepository.save(cargo);
        redirectAttributes.addFlashAttribute("message", "Cargo salvo com sucesso!");
        return "redirect:/cargos";
    }
}