package com.igordmoro.farmacia.GestaoFarmacia.service;

import com.igordmoro.farmacia.GestaoFarmacia.entity.Cargo;
import com.igordmoro.farmacia.GestaoFarmacia.entity.Funcionario;
import com.igordmoro.farmacia.GestaoFarmacia.entity.Setor;
import com.igordmoro.farmacia.GestaoFarmacia.repository.CargoRepository;
import com.igordmoro.farmacia.GestaoFarmacia.repository.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FuncionarioService {

    private final FuncionarioRepository funcionarioRepository;
    private final CargoRepository cargoRepository;

    @Autowired
    public FuncionarioService(FuncionarioRepository funcionarioRepository, CargoRepository cargoRepository) {
        this.funcionarioRepository = funcionarioRepository;
        this.cargoRepository = cargoRepository;
    }

    @Transactional
    public Funcionario salvarFuncionario(Funcionario funcionario) {
        if (funcionario.getCargo() == null || funcionario.getCargo().getId() == null) {
            throw new IllegalArgumentException("Cargo é obrigatório para o funcionário.");
        }
        // Garante que o Cargo seja uma entidade gerenciada antes de salvar o funcionário
        Cargo cargoExistente = cargoRepository.findById(funcionario.getCargo().getId())
                .orElseThrow(() -> new NoSuchElementException("Cargo não encontrado com ID: " + funcionario.getCargo().getId()));

        funcionario.setCargo(cargoExistente); // Associa o cargo gerenciado
        calcularSalarioELimposto(funcionario); // Calcula antes de salvar

        return funcionarioRepository.save(funcionario);
    }

    public List<Funcionario> listarTodosFuncionarios() {
        List<Funcionario> funcionarios = funcionarioRepository.findAll();
        // Garante que os valores calculados estejam atualizados ao listar, se a lógica de cálculo for complexa
        funcionarios.forEach(this::calcularSalarioELimposto);
        return funcionarios;
    }

    public Optional<Funcionario> buscarFuncionarioPorId(Long id) {
        Optional<Funcionario> funcionario = funcionarioRepository.findById(id);
        funcionario.ifPresent(this::calcularSalarioELimposto); // Calcula se encontrado
        return funcionario;
    }

    @Transactional
    public Funcionario atualizarFuncionario(Long id, Funcionario funcionarioDetails) {
        Funcionario funcionarioExistente = funcionarioRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Funcionário não encontrado com ID: " + id));

        // Atualiza campos básicos
        funcionarioExistente.setNome(funcionarioDetails.getNome());
        funcionarioExistente.setSalarioBruto(funcionarioDetails.getSalarioBruto());
        funcionarioExistente.setIdade(funcionarioDetails.getIdade());
        funcionarioExistente.setGenero(funcionarioDetails.getGenero());

        // Se um novo Cargo foi fornecido, valide e associe-o
        if (funcionarioDetails.getCargo() != null && funcionarioDetails.getCargo().getId() != null) {
            Cargo novoCargo = cargoRepository.findById(funcionarioDetails.getCargo().getId())
                    .orElseThrow(() -> new NoSuchElementException("Novo Cargo não encontrado com ID: " + funcionarioDetails.getCargo().getId()));
            funcionarioExistente.setCargo(novoCargo);
        } else if (funcionarioDetails.getCargo() == null) {
            throw new IllegalArgumentException("Cargo não pode ser nulo na atualização.");
        }

        calcularSalarioELimposto(funcionarioExistente); // Recalcula com os novos dados
        return funcionarioRepository.save(funcionarioExistente);
    }

    @Transactional
    public void deletarFuncionario(Long id) {
        if (!funcionarioRepository.existsById(id)) {
            throw new NoSuchElementException("Funcionário não encontrado para deletar com ID: " + id);
        }
        funcionarioRepository.deleteById(id);
    }

    public List<Funcionario> buscarFuncionariosPorSetor(Setor setor) {
        List<Funcionario> funcionarios = funcionarioRepository.findByCargo_Setor(setor);
        funcionarios.forEach(this::calcularSalarioELimposto);
        return funcionarios;
    }

    public Map<String, Long> contarFuncionariosPorSetor() {
        return funcionarioRepository.findAll().stream()
                .filter(f -> f.getCargo() != null && f.getCargo().getSetor() != null)
                .collect(Collectors.groupingBy(f -> f.getCargo().getSetor().name(), Collectors.counting()));
    }

    // NOVO MÉTODO: Contar funcionários por cargo
    public Map<Long, Long> contarFuncionariosPorCargo() {
        return funcionarioRepository.findAll().stream()
                .filter(f -> f.getCargo() != null)
                .collect(Collectors.groupingBy(f -> f.getCargo().getId(), Collectors.counting()));
    }

    private void calcularSalarioELimposto(Funcionario funcionario) {
        double salarioBruto = funcionario.getSalarioBruto();
        double imposto = 0;
        double salarioLiquido = salarioBruto;

        // Regra de imposto simples (exemplo)
        if (salarioBruto > 5000) {
            imposto = salarioBruto * 0.20;
        } else if (salarioBruto > 2000) {
            imposto = salarioBruto * 0.10;
        }

        salarioLiquido -= imposto;

        // Descontos de benefícios do cargo
        if (funcionario.getCargo() != null) {
            Cargo cargo = funcionario.getCargo();
            salarioLiquido -= cargo.getValeAlimento();
            salarioLiquido -= cargo.getValeTransporte();
            salarioLiquido -= cargo.getPlanoSaude();
            salarioLiquido -= cargo.getPlanoOdonto();
        }

        // Garante que o salário líquido não seja negativo
        if (salarioLiquido < 0) {
            salarioLiquido = 0;
        }

        funcionario.setImposto(imposto);
        funcionario.setSalarioLiquido(salarioLiquido);
    }
}