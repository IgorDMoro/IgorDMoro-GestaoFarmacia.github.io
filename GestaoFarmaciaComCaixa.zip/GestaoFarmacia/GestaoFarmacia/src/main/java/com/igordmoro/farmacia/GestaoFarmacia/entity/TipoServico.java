package com.igordmoro.farmacia.GestaoFarmacia.entity;

public enum TipoServico {
	COMPRA,
	VENDA
}
